#pragma once
class SMAVal {
	int
		x,
		y;

	SMAVal();
	SMAVal(int x, int y) {
		this->x = x;
		this->y = y;
	}
};