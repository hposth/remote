#pragma once
class SMAVal {
public:
	int 
		x,
		y;

	SMAVal() {}
	SMAVal(int x, int y) {
		this->x = x;
		this->y = y;
	}
};